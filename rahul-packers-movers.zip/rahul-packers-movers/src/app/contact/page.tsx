'use client';

import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, MessageCircle } from 'lucide-react';

export default function Contact() {
  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="font-display text-4xl font-bold mb-4">Contact Us</h1>
            <p className="text-gray-400">Get in touch with us for any queries</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <div className="glass-card p-6">
                <Phone className="text-accent-orange mb-4" size={32} />
                <h3 className="font-semibold mb-2">Phone</h3>
                <a href="tel:+919119289125" className="text-gray-400 hover:text-accent-orange">
                  +91 9119289125
                </a>
              </div>

              <div className="glass-card p-6">
                <MessageCircle className="text-green-500 mb-4" size={32} />
                <h3 className="font-semibold mb-2">WhatsApp</h3>
                <a
                  href="https://wa.me/919119289125"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-green-500"
                >
                  Chat on WhatsApp
                </a>
              </div>

              <div className="glass-card p-6">
                <Mail className="text-accent-blue mb-4" size={32} />
                <h3 className="font-semibold mb-2">Email</h3>
                <a href="mailto:info@rahulpackers.com" className="text-gray-400 hover:text-accent-blue">
                  info@rahulpackers.com
                </a>
              </div>
            </div>

            <div className="glass-card p-8">
              <h3 className="font-display text-xl font-bold mb-6">Send Message</h3>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                />
                <input
                  type="email"
                  placeholder="Email"
                  className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                />
                <input
                  type="tel"
                  placeholder="Phone"
                  className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                />
                <textarea
                  placeholder="Message"
                  rows={4}
                  className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                />
                <button type="submit" className="btn-primary w-full">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
