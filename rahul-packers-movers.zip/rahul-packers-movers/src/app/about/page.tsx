'use client';

import { motion } from 'framer-motion';

export default function About() {
  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="font-display text-4xl font-bold mb-4">About Us</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              India's Trusted Relocation Partner
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-display text-2xl font-bold mb-4">Our Story</h2>
              <p className="text-gray-400 mb-4">
                Rahul Packers and Movers has been providing reliable relocation services
                across India. We understand that moving can be stressful, and our mission
                is to make it smooth and hassle-free.
              </p>
              <p className="text-gray-400">
                With our experienced team, modern equipment, and commitment to customer
                satisfaction, we have become one of the most trusted names in the
                relocation industry.
              </p>
            </div>
            <div className="glass-card p-8">
              <h3 className="font-display text-xl font-bold mb-4">Why Choose Us</h3>
              <ul className="space-y-3 text-gray-400">
                <li>✓ Professional and experienced team</li>
                <li>✓ GPS-tracked transportation</li>
                <li>✓ Comprehensive insurance coverage</li>
                <li>✓ 24/7 customer support</li>
                <li>✓ Transparent pricing</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
