'use client';

import { motion } from 'framer-motion';
import Hero from '@/components/Hero';
import QuoteForm from '@/components/QuoteForm';
import Services from '@/components/Services';
import MovingJourney from '@/components/MovingJourney';
import PanIndiaCoverage from '@/components/PanIndiaCoverage';
import TrustBadges from '@/components/TrustBadges';

export default function Home() {
  return (
    <>
      <Hero />
      <TrustBadges />
      <QuoteForm />
      <Services />
      <MovingJourney />
      <PanIndiaCoverage />
    </>
  );
}
