'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, CheckCircle, Truck, Package, MapPin, Home } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

type TrackingStep = { icon: LucideIcon; label: string; completed: boolean };
type TrackingData = { bookingId: string; status: string; steps: TrackingStep[] };

export default function Tracking() {
  const [bookingId, setBookingId] = useState('');
  const [trackingData, setTrackingData] = useState<TrackingData | null>(null);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate tracking data
    setTrackingData({
      bookingId,
      status: 'In Transit',
      steps: [
        { icon: CheckCircle, label: 'Booking Confirmed', completed: true },
        { icon: Package, label: 'Packing Completed', completed: true },
        { icon: Truck, label: 'Vehicle Picked Up', completed: true },
        { icon: MapPin, label: 'In Transit', completed: true },
        { icon: Home, label: 'Delivered', completed: false },
      ],
    });
  };

  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="font-display text-4xl font-bold mb-4">Track Your Shipment</h1>
            <p className="text-gray-400">Enter your booking ID to track your shipment</p>
          </motion.div>

          <form onSubmit={handleTrack} className="glass-card p-8 mb-8">
            <div className="flex gap-4">
              <input
                type="text"
                placeholder="Enter Booking ID (e.g., RPM20260001)"
                value={bookingId}
                onChange={(e) => setBookingId(e.target.value)}
                className="flex-1 p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
              />
              <button type="submit" className="btn-primary flex items-center gap-2">
                <Search size={20} />
                Track
              </button>
            </div>
          </form>

          {trackingData && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card p-8"
            >
              <h3 className="font-display text-xl font-bold mb-6">
                Booking ID: {trackingData.bookingId}
              </h3>
              <div className="space-y-4">
                {trackingData.steps.map((step, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        step.completed ? 'bg-accent-orange' : 'bg-gray-700'
                      }`}
                    >
                      <step.icon size={20} />
                    </div>
                    <span className={step.completed ? 'text-white' : 'text-gray-500'}>
                      {step.label}
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </section>
    </div>
  );
}
