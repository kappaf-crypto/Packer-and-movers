'use client';

import { motion } from 'framer-motion';
import { Home, Building, Car, Bike, Briefcase, Warehouse, ArrowRight } from 'lucide-react';

const services = [
  {
    icon: Home,
    title: 'Home Relocation',
    description: 'Complete home shifting solutions with professional packing and safe transportation.',
  },
  {
    icon: Building,
    title: 'Office Relocation',
    description: 'Seamless office moving services with minimal downtime and maximum efficiency.',
  },
  {
    icon: Car,
    title: 'Car Transportation',
    description: 'Safe car carrier services with specialized vehicles for secure transportation.',
  },
  {
    icon: Bike,
    title: 'Bike Transportation',
    description: 'Secure bike transport with proper packaging and handling.',
  },
  {
    icon: Briefcase,
    title: 'Corporate Relocation',
    description: 'Employee relocation services for smooth business transitions.',
  },
  {
    icon: Warehouse,
    title: 'Storage Solutions',
    description: 'Warehouse and storage facilities for short and long-term needs.',
  },
];

export default function Services() {
  return (
    <section className="py-20 bg-navy-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-4xl font-bold mb-4">Our Services</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Comprehensive relocation solutions tailored to your needs
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-card p-6 hover:border-accent-orange/50 transition-all"
            >
              <service.icon className="text-accent-orange mb-4" size={40} />
              <h3 className="font-display text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-400 mb-4">{service.description}</p>
              <button className="flex items-center gap-2 text-accent-orange hover:gap-3 transition-all">
                Learn More <ArrowRight size={16} />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
