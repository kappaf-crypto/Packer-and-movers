'use client';

import { motion } from 'framer-motion';
import { MapPin, Route, Headphones } from 'lucide-react';

const stats = [
  { icon: MapPin, value: '50+', label: 'Cities' },
  { icon: Route, value: '200+', label: 'Routes' },
  { icon: Headphones, value: '24/7', label: 'Support' },
];

export default function PanIndiaCoverage() {
  return (
    <section className="py-20 bg-navy-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-4xl font-bold mb-4">Pan India Coverage</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Serving across India with extensive network and reliable services
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-card p-8 text-center"
            >
              <stat.icon className="text-accent-orange mx-auto mb-4" size={40} />
              <div className="font-display text-4xl font-bold gradient-text mb-2">{stat.value}</div>
              <div className="text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
