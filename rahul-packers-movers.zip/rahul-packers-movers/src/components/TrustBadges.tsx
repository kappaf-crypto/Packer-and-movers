'use client';

import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

const badges = [
  'Verified Packers',
  'Door-to-Door Delivery',
  'Live Tracking',
  'Secure Packing',
];

export default function TrustBadges() {
  return (
    <section className="py-12 bg-navy-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {badges.map((badge, index) => (
            <motion.div
              key={badge}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="flex items-center gap-2 justify-center p-4 glass-card"
            >
              <CheckCircle className="text-accent-orange" size={20} />
              <span className="text-sm font-medium">{badge}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
