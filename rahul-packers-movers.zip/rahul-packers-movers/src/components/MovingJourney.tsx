'use client';

import { motion } from 'framer-motion';
import { Package, Truck, MapPin, Home } from 'lucide-react';

const steps = [
  { icon: Package, title: 'Professional Packing', description: 'Expert packing with premium materials' },
  { icon: Truck, title: 'Safe Loading', description: 'Careful loading with modern equipment' },
  { icon: MapPin, title: 'Transportation', description: 'GPS-tracked safe transportation' },
  { icon: Home, title: 'Doorstep Delivery', description: 'On-time delivery to your doorstep' },
];

export default function MovingJourney() {
  return (
    <section className="py-20 bg-navy-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-4xl font-bold mb-4">Your Moving Journey</h2>
          <p className="text-gray-400">Simple 4-step process for hassle-free relocation</p>
        </motion.div>

        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-accent-orange/20 flex items-center justify-center">
                <step.icon className="text-accent-orange" size={32} />
              </div>
              <h3 className="font-display text-xl font-semibold mb-2">{step.title}</h3>
              <p className="text-gray-400">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
