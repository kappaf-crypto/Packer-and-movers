'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';

export default function QuoteForm() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    fromCity: '',
    toCity: '',
    houseSize: '',
    movingDate: '',
    serviceType: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    alert('Thank you! We will contact you soon.');
  };

  return (
    <section id="quote" className="py-20 bg-navy-950">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-card p-8"
        >
          <h2 className="font-display text-3xl font-bold text-center mb-8">
            Get Free Moving Quote
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <input
                type="text"
                placeholder="Your Name"
                required
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
              <input
                type="tel"
                placeholder="Phone Number"
                required
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
              <input
                type="email"
                placeholder="Email"
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
              <input
                type="text"
                placeholder="Moving From"
                required
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.fromCity}
                onChange={(e) => setFormData({ ...formData, fromCity: e.target.value })}
              />
              <input
                type="text"
                placeholder="Moving To"
                required
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.toCity}
                onChange={(e) => setFormData({ ...formData, toCity: e.target.value })}
              />
              <select
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.houseSize}
                onChange={(e) => setFormData({ ...formData, houseSize: e.target.value })}
              >
                <option value="">House Size</option>
                <option value="1rk">1 RK</option>
                <option value="1bhk">1 BHK</option>
                <option value="2bhk">2 BHK</option>
                <option value="3bhk">3 BHK</option>
                <option value="4bhk">4 BHK+</option>
              </select>
              <input
                type="date"
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.movingDate}
                onChange={(e) => setFormData({ ...formData, movingDate: e.target.value })}
              />
              <select
                className="w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none"
                value={formData.serviceType}
                onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
              >
                <option value="">Service Type</option>
                <option value="home">Home Relocation</option>
                <option value="office">Office Relocation</option>
                <option value="car">Car Transportation</option>
                <option value="bike">Bike Transportation</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full btn-primary text-lg"
            >
              Get Free Moving Quote
            </button>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
