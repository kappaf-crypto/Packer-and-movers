'use client';

import { Phone, MessageCircle } from 'lucide-react';

export default function MobileActionBar() {
  return (
    <div className="fixed bottom-0 left-0 right-0 md:hidden bg-navy-950/95 backdrop-blur-lg border-t border-white/10 p-4 z-50">
      <div className="flex gap-4">
        <a
          href="tel:+919119289125"
          className="flex-1 flex items-center justify-center gap-2 bg-accent-orange text-white py-3 rounded-full font-semibold"
        >
          <Phone size={20} />
          Call
        </a>
        <a
          href="https://wa.me/919119289125"
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-full font-semibold"
        >
          <MessageCircle size={20} />
          WhatsApp
        </a>
      </div>
    </div>
  );
}
