import Link from 'next/link';
import { Phone, Mail, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-navy-950 border-t border-white/10 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-display text-xl font-bold mb-4">
              <span className="gradient-text">Rahul Packers and Movers</span>
            </h3>
            <p className="text-gray-400">India's Trusted Relocation Partner</p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-400 hover:text-accent-orange">Home</Link></li>
              <li><Link href="/about" className="text-gray-400 hover:text-accent-orange">About</Link></li>
              <li><Link href="/services" className="text-gray-400 hover:text-accent-orange">Services</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-accent-orange">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><Link href="/services/home-relocation" className="text-gray-400 hover:text-accent-orange">Home Relocation</Link></li>
              <li><Link href="/services/office-relocation" className="text-gray-400 hover:text-accent-orange">Office Relocation</Link></li>
              <li><Link href="/services/car-transport" className="text-gray-400 hover:text-accent-orange">Car Transport</Link></li>
              <li><Link href="/services/storage" className="text-gray-400 hover:text-accent-orange">Storage</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-2">
              <li className="flex items-center gap-2 text-gray-400">
                <Phone size={16} />
                <a href="tel:+919119289125" className="hover:text-accent-orange">+91 9119289125</a>
              </li>
              <li className="flex items-center gap-2 text-gray-400">
                <Mail size={16} />
                <a href="mailto:info@rahulpackers.com" className="hover:text-accent-orange">info@rahulpackers.com</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Rahul Packers and Movers. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
