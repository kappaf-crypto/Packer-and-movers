</main>

<footer class="bg-navy-950 border-t border-white/10 py-12">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid md:grid-cols-4 gap-8">
      <div>
        <h3 class="font-display text-xl font-bold mb-4">
          <span class="gradient-text">Rahul Packers and Movers</span>
        </h3>
        <p class="text-gray-400">India's Trusted Relocation Partner</p>
      </div>

      <div>
        <h4 class="font-semibold mb-4">Quick Links</h4>
        <ul class="space-y-2">
          <li><a href="<?php echo esc_url(home_url('/')); ?>" class="text-gray-400 hover:text-accent-orange">Home</a></li>
          <li><a href="<?php echo esc_url(home_url('/about/')); ?>" class="text-gray-400 hover:text-accent-orange">About</a></li>
          <li><a href="<?php echo esc_url(home_url('/services/')); ?>" class="text-gray-400 hover:text-accent-orange">Services</a></li>
          <li><a href="<?php echo esc_url(home_url('/contact/')); ?>" class="text-gray-400 hover:text-accent-orange">Contact</a></li>
        </ul>
      </div>

      <div>
        <h4 class="font-semibold mb-4">Services</h4>
        <ul class="space-y-2">
          <li><a href="<?php echo esc_url(home_url('/services/home-relocation/')); ?>" class="text-gray-400 hover:text-accent-orange">Home Relocation</a></li>
          <li><a href="<?php echo esc_url(home_url('/services/office-relocation/')); ?>" class="text-gray-400 hover:text-accent-orange">Office Relocation</a></li>
          <li><a href="<?php echo esc_url(home_url('/services/car-transport/')); ?>" class="text-gray-400 hover:text-accent-orange">Car Transport</a></li>
          <li><a href="<?php echo esc_url(home_url('/services/storage/')); ?>" class="text-gray-400 hover:text-accent-orange">Storage</a></li>
        </ul>
      </div>

      <div>
        <h4 class="font-semibold mb-4">Contact</h4>
        <ul class="space-y-2">
          <li class="flex items-center gap-2 text-gray-400">
            <?php echo rpm_icon('phone', 16); ?>
            <a href="<?php echo esc_url(rpm_tel()); ?>" class="hover:text-accent-orange"><?php echo esc_html(rpm_phone()); ?></a>
          </li>
          <li class="flex items-center gap-2 text-gray-400">
            <?php echo rpm_icon('mail', 16); ?>
            <a href="mailto:<?php echo esc_attr(rpm_email()); ?>" class="hover:text-accent-orange"><?php echo esc_html(rpm_email()); ?></a>
          </li>
        </ul>
      </div>
    </div>

    <div class="border-t border-white/10 mt-8 pt-8 text-center text-gray-400">
      <p>&copy; <?php echo esc_html(date_i18n('Y')); ?> Rahul Packers and Movers. All rights reserved.</p>
    </div>
  </div>
</footer>

<div class="fixed bottom-0 left-0 right-0 md:hidden bg-navy-950/95 backdrop-blur-lg border-t border-white/10 p-4 z-50">
  <div class="flex gap-4">
    <a href="<?php echo esc_url(rpm_tel()); ?>" class="flex-1 flex items-center justify-center gap-2 bg-accent-orange text-white py-3 rounded-full font-semibold">
      <?php echo rpm_icon('phone', 20); ?>
      Call
    </a>
    <a href="<?php echo esc_url(rpm_wa()); ?>" target="_blank" rel="noopener noreferrer" class="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-full font-semibold">
      <?php echo rpm_icon('message-circle', 20); ?>
      WhatsApp
    </a>
  </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
