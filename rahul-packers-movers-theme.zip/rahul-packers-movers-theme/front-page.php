<?php
/**
 * Home page template.
 */
get_header();

get_template_part('template-parts/hero');
get_template_part('template-parts/trust-badges');
get_template_part('template-parts/quote-form');
get_template_part('template-parts/services');
get_template_part('template-parts/moving-journey');
get_template_part('template-parts/pan-india');

get_footer();
