<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>document.documentElement.className += ' js';</script>
<?php wp_head(); ?>
</head>
<body <?php body_class('font-sans'); ?>>
<?php wp_body_open(); ?>

<nav class="rpm-nav fixed top-0 left-0 right-0 z-50 bg-navy-950/80 backdrop-blur-lg border-b border-white/10">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between h-16">
      <?php if (has_custom_logo()) : ?>
        <?php the_custom_logo(); ?>
      <?php else : ?>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="font-display font-bold text-xl">
          <span class="gradient-text">Rahul Packers</span>
        </a>
      <?php endif; ?>

      <div class="hidden md:flex items-center space-x-8">
        <?php foreach (rpm_nav_items() as $item) : ?>
          <a href="<?php echo esc_url($item['url']); ?>" class="text-gray-300 hover:text-accent-orange transition-colors"><?php echo esc_html($item['name']); ?></a>
        <?php endforeach; ?>
      </div>

      <div class="hidden md:flex items-center">
        <a href="<?php echo esc_url(rpm_tel()); ?>" class="flex items-center gap-2 bg-accent-orange hover:bg-accent-orange/90 text-white px-4 py-2 rounded-full transition-all">
          <?php echo rpm_icon('phone', 16); ?>
          <span><?php echo esc_html(rpm_phone()); ?></span>
        </a>
      </div>

      <button id="rpm-menu-btn" type="button" class="md:hidden text-white" aria-label="Toggle menu" aria-expanded="false" aria-controls="rpm-mobile-menu">
        <span data-icon="open"><?php echo rpm_icon('menu', 24); ?></span>
        <span data-icon="close" class="hidden"><?php echo rpm_icon('x', 24); ?></span>
      </button>
    </div>
  </div>

  <div id="rpm-mobile-menu" class="hidden md:hidden bg-navy-950/95 backdrop-blur-lg">
    <div class="px-4 py-4 space-y-4">
      <?php foreach (rpm_nav_items() as $item) : ?>
        <a href="<?php echo esc_url($item['url']); ?>" class="block text-gray-300 hover:text-accent-orange transition-colors"><?php echo esc_html($item['name']); ?></a>
      <?php endforeach; ?>
      <a href="<?php echo esc_url(rpm_tel()); ?>" class="flex items-center justify-center gap-2 bg-accent-orange text-white px-4 py-2 rounded-full">
        <?php echo rpm_icon('phone', 16); ?>
        <span>Call Now</span>
      </a>
    </div>
  </div>
</nav>

<main>
