<?php
/**
 * Rahul Packers and Movers theme functions.
 */
if (!defined('ABSPATH')) {
    exit;
}

define('RPM_VERSION', '1.0.0');

/* ---------------------------------------------------------------
 * Setup & assets
 * ------------------------------------------------------------- */
function rpm_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array('height' => 40, 'width' => 200, 'flex-width' => true, 'flex-height' => true));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    register_nav_menus(array(
        'primary' => 'Primary Menu',
    ));
}
add_action('after_setup_theme', 'rpm_setup');

function rpm_assets() {
    wp_enqueue_style(
        'rpm-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap',
        array(),
        null
    );
    $css = get_template_directory() . '/assets/css/main.css';
    $js  = get_template_directory() . '/assets/js/main.js';
    wp_enqueue_style('rpm-main', get_template_directory_uri() . '/assets/css/main.css', array('rpm-fonts'), file_exists($css) ? filemtime($css) : RPM_VERSION);
    wp_enqueue_script('rpm-main', get_template_directory_uri() . '/assets/js/main.js', array(), file_exists($js) ? filemtime($js) : RPM_VERSION, true);
}
add_action('wp_enqueue_scripts', 'rpm_assets');

/* Front page meta description (only when no SEO plugin is active) */
function rpm_meta_description() {
    if (is_front_page() && !defined('WPSEO_VERSION') && !defined('RANK_MATH_VERSION') && !defined('AIOSEO_VERSION')) {
        echo '<meta name="description" content="Safe packing, reliable transportation and doorstep relocation services across India.">' . "\n";
    }
}
add_action('wp_head', 'rpm_meta_description', 1);

/* ---------------------------------------------------------------
 * Helpers
 * ------------------------------------------------------------- */
function rpm_icon($name, $size = 24, $class = '') {
    static $cache = array();
    if (!isset($cache[$name])) {
        $file = get_template_directory() . '/assets/icons/' . sanitize_file_name($name) . '.svg';
        $cache[$name] = file_exists($file) ? file_get_contents($file) : '';
    }
    if ($cache[$name] === '') {
        return '';
    }
    return str_replace(
        '<svg',
        '<svg aria-hidden="true" width="' . (int) $size . '" height="' . (int) $size . '" class="' . esc_attr($class) . '"',
        $cache[$name]
    );
}

function rpm_digits($s) {
    return preg_replace('/\D+/', '', (string) $s);
}
function rpm_phone() {
    return get_theme_mod('rpm_phone', '+91 9119289125');
}
function rpm_tel() {
    return 'tel:+' . rpm_digits(rpm_phone());
}
function rpm_wa() {
    $n = get_theme_mod('rpm_whatsapp', '');
    return 'https://wa.me/' . rpm_digits($n !== '' ? $n : rpm_phone());
}
function rpm_email() {
    return get_theme_mod('rpm_email', 'info@rahulpackers.com');
}

function rpm_nav_items() {
    $items = array();
    $locations = get_nav_menu_locations();
    if (!empty($locations['primary'])) {
        $menu_items = wp_get_nav_menu_items($locations['primary']);
        if ($menu_items) {
            foreach ($menu_items as $mi) {
                if ((int) $mi->menu_item_parent === 0) {
                    $items[] = array('name' => $mi->title, 'url' => $mi->url);
                }
            }
        }
    }
    if (!$items) {
        $items = array(
            array('name' => 'Home',     'url' => home_url('/')),
            array('name' => 'About',    'url' => home_url('/about/')),
            array('name' => 'Services', 'url' => home_url('/services/')),
            array('name' => 'Cities',   'url' => home_url('/cities/')),
            array('name' => 'Tracking', 'url' => home_url('/tracking/')),
            array('name' => 'Contact',  'url' => home_url('/contact/')),
        );
    }
    return $items;
}

function rpm_field_class() {
    return 'w-full p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none';
}

function rpm_form_notice() {
    if (!isset($_GET['rpm_sent'])) {
        return;
    }
    $state = sanitize_key(wp_unslash($_GET['rpm_sent']));
    if ($state === '1') {
        echo '<div class="mb-6 p-4 rounded-lg bg-green-600/20 border border-green-500/40 text-green-300 text-center" role="status">Thank you! We will contact you soon.</div>';
    } elseif ($state === 'missing') {
        echo '<div class="mb-6 p-4 rounded-lg bg-red-600/20 border border-red-500/40 text-red-300 text-center" role="alert">Please fill in all required fields.</div>';
    } elseif ($state === 'error') {
        echo '<div class="mb-6 p-4 rounded-lg bg-red-600/20 border border-red-500/40 text-red-300 text-center" role="alert">Something went wrong. Please try again or call us.</div>';
    }
}

/* ---------------------------------------------------------------
 * Customizer: contact details
 * ------------------------------------------------------------- */
function rpm_customize($wp_customize) {
    $wp_customize->add_section('rpm_contact', array('title' => 'Contact Details', 'priority' => 30));
    $fields = array(
        'rpm_phone'    => array('Phone number (shown in header, hero, footer)', '+91 9119289125', 'sanitize_text_field'),
        'rpm_whatsapp' => array('WhatsApp number (leave empty to use phone)', '', 'sanitize_text_field'),
        'rpm_email'    => array('Email address', 'info@rahulpackers.com', 'sanitize_email'),
    );
    foreach ($fields as $id => $f) {
        $wp_customize->add_setting($id, array('default' => $f[1], 'sanitize_callback' => $f[2]));
        $wp_customize->add_control($id, array('label' => $f[0], 'section' => 'rpm_contact', 'type' => 'text'));
    }
}
add_action('customize_register', 'rpm_customize');

/* ---------------------------------------------------------------
 * Custom post types: quote requests & shipments
 * ------------------------------------------------------------- */
function rpm_register_cpts() {
    register_post_type('quote_request', array(
        'labels' => array('name' => 'Quote Requests', 'singular_name' => 'Quote Request', 'menu_name' => 'Quote Requests'),
        'public' => false,
        'show_ui' => true,
        'menu_icon' => 'dashicons-email-alt',
        'menu_position' => 25,
        'supports' => array('title'),
        'capability_type' => 'post',
        'capabilities' => array('create_posts' => 'do_not_allow'),
        'map_meta_cap' => true,
    ));
    register_post_type('shipment', array(
        'labels' => array(
            'name' => 'Shipments', 'singular_name' => 'Shipment', 'menu_name' => 'Shipments',
            'add_new_item' => 'Add New Shipment', 'edit_item' => 'Edit Shipment',
            'title_placeholder' => 'Booking ID (e.g. RPM20260001)',
        ),
        'public' => false,
        'show_ui' => true,
        'menu_icon' => 'dashicons-location-alt',
        'menu_position' => 26,
        'supports' => array('title'),
    ));
}
add_action('init', 'rpm_register_cpts');

function rpm_steps() {
    return array(
        array('label' => 'Booking Confirmed', 'icon' => 'check-circle'),
        array('label' => 'Packing Completed', 'icon' => 'package'),
        array('label' => 'Vehicle Picked Up', 'icon' => 'truck'),
        array('label' => 'In Transit',        'icon' => 'map-pin'),
        array('label' => 'Delivered',         'icon' => 'home'),
    );
}

function rpm_add_meta_boxes() {
    add_meta_box('rpm_shipment_box', 'Shipment status', 'rpm_shipment_box_cb', 'shipment', 'normal', 'high');
    add_meta_box('rpm_request_box', 'Request details', 'rpm_request_box_cb', 'quote_request', 'normal', 'high');
}
add_action('add_meta_boxes', 'rpm_add_meta_boxes');

function rpm_shipment_box_cb($post) {
    wp_nonce_field('rpm_ship', 'rpm_ship_nonce');
    $step  = (int) get_post_meta($post->ID, 'rpm_step', true);
    $step  = $step ? $step : 1;
    $route = get_post_meta($post->ID, 'rpm_route', true);
    echo '<p><label for="rpm_step"><strong>Current stage</strong></label><br><select name="rpm_step" id="rpm_step">';
    foreach (rpm_steps() as $i => $s) {
        printf('<option value="%d"%s>%d. %s</option>', $i + 1, selected($step, $i + 1, false), $i + 1, esc_html($s['label']));
    }
    echo '</select></p>';
    echo '<p><label for="rpm_route"><strong>Route (optional, e.g. Jaipur to Mumbai)</strong></label><br>';
    echo '<input type="text" class="widefat" name="rpm_route" id="rpm_route" value="' . esc_attr($route) . '"></p>';
    echo '<p class="description">The post title is the Booking ID customers enter on the Tracking page.</p>';
}

function rpm_save_shipment($post_id) {
    if (!isset($_POST['rpm_ship_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['rpm_ship_nonce'])), 'rpm_ship')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    $step = isset($_POST['rpm_step']) ? (int) $_POST['rpm_step'] : 1;
    update_post_meta($post_id, 'rpm_step', max(1, min(5, $step)));
    update_post_meta($post_id, 'rpm_route', isset($_POST['rpm_route']) ? sanitize_text_field(wp_unslash($_POST['rpm_route'])) : '');
}
add_action('save_post_shipment', 'rpm_save_shipment');

function rpm_request_box_cb($post) {
    $data = get_post_meta($post->ID, 'rpm_data', true);
    if (!is_array($data) || !$data) {
        echo '<p>No details saved.</p>';
        return;
    }
    echo '<table class="widefat striped"><tbody>';
    foreach ($data as $k => $v) {
        if ($v === '') {
            continue;
        }
        echo '<tr><th style="width:160px">' . esc_html(ucwords(str_replace('_', ' ', $k))) . '</th><td>' . nl2br(esc_html($v)) . '</td></tr>';
    }
    echo '</tbody></table>';
}

/* ---------------------------------------------------------------
 * Form handler (quote form + contact form)
 * ------------------------------------------------------------- */
function rpm_handle_form() {
    $back = wp_get_referer();
    $back = $back ? remove_query_arg('rpm_sent', strtok($back, '#')) : home_url('/');

    $nonce = isset($_POST['rpm_nonce']) ? sanitize_text_field(wp_unslash($_POST['rpm_nonce'])) : '';
    $type  = (isset($_POST['rpm_type']) && $_POST['rpm_type'] === 'message') ? 'message' : 'quote';
    $frag  = $type === 'message' ? '#contact-form' : '#quote';

    if (!wp_verify_nonce($nonce, 'rpm_form')) {
        wp_safe_redirect(add_query_arg('rpm_sent', 'error', $back) . $frag);
        exit;
    }
    // Honeypot: bots fill this hidden field
    if (!empty($_POST['rpm_website'])) {
        wp_safe_redirect(add_query_arg('rpm_sent', '1', $back) . $frag);
        exit;
    }

    $in = (isset($_POST['rpm']) && is_array($_POST['rpm'])) ? wp_unslash($_POST['rpm']) : array();
    $get = function ($k) use ($in) {
        return (isset($in[$k]) && is_string($in[$k])) ? $in[$k] : '';
    };
    $clean = array(
        'name'         => sanitize_text_field($get('name')),
        'phone'        => sanitize_text_field($get('phone')),
        'email'        => sanitize_email($get('email')),
        'from_city'    => sanitize_text_field($get('from_city')),
        'to_city'      => sanitize_text_field($get('to_city')),
        'house_size'   => sanitize_text_field($get('house_size')),
        'moving_date'  => sanitize_text_field($get('moving_date')),
        'service_type' => sanitize_text_field($get('service_type')),
        'message'      => sanitize_textarea_field($get('message')),
    );

    $required = $type === 'quote' ? array('name', 'phone', 'from_city', 'to_city') : array('name', 'phone');
    foreach ($required as $k) {
        if ($clean[$k] === '') {
            wp_safe_redirect(add_query_arg('rpm_sent', 'missing', $back) . $frag);
            exit;
        }
    }

    $title = $type === 'quote'
        ? sprintf('Quote: %s (%s to %s)', $clean['name'], $clean['from_city'], $clean['to_city'])
        : sprintf('Message: %s', $clean['name']);

    $post_id = wp_insert_post(array(
        'post_type'   => 'quote_request',
        'post_status' => 'publish',
        'post_title'  => $title,
    ));
    if ($post_id && !is_wp_error($post_id)) {
        $clean['type'] = $type;
        update_post_meta($post_id, 'rpm_data', $clean);
    }

    $lines = array();
    foreach ($clean as $k => $v) {
        if ($v !== '') {
            $lines[] = ucwords(str_replace('_', ' ', $k)) . ': ' . $v;
        }
    }
    $headers = array();
    if (is_email($clean['email'])) {
        $headers[] = 'Reply-To: ' . $clean['name'] . ' <' . $clean['email'] . '>';
    }
    wp_mail(get_option('admin_email'), '[' . get_bloginfo('name') . '] ' . $title, implode("\n", $lines), $headers);

    wp_safe_redirect(add_query_arg('rpm_sent', '1', $back) . $frag);
    exit;
}
add_action('admin_post_nopriv_rpm_form', 'rpm_handle_form');
add_action('admin_post_rpm_form', 'rpm_handle_form');
