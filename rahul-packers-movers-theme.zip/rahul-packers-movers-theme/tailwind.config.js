const path = require('path');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    path.join(__dirname, '*.php'),
    path.join(__dirname, 'template-parts/**/*.php'),
    path.join(__dirname, 'assets/js/**/*.js'),
  ],
  theme: {
    extend: {
      colors: {
        navy: { 900: '#0a1628', 950: '#050d1a' },
        accent: { orange: '#ff6b35', blue: '#0066ff' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Poppins', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
