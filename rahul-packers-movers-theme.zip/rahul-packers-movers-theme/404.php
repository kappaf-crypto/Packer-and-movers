<?php get_header(); ?>
<div class="pt-16">
  <section class="py-32 text-center">
    <div class="max-w-2xl mx-auto px-4">
      <h1 class="font-display text-6xl font-bold mb-4 gradient-text">404</h1>
      <p class="text-gray-400 mb-8">This page could not be found.</p>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="btn-primary inline-block">Back to Home</a>
    </div>
  </section>
</div>
<?php get_footer(); ?>
