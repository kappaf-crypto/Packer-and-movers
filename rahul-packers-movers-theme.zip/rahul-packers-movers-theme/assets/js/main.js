(function () {
  'use strict';

  // Mobile menu toggle
  var btn = document.getElementById('rpm-menu-btn');
  var menu = document.getElementById('rpm-mobile-menu');
  if (btn && menu) {
    var iconOpen = btn.querySelector('[data-icon="open"]');
    var iconClose = btn.querySelector('[data-icon="close"]');
    var setOpen = function (open) {
      menu.classList.toggle('hidden', !open);
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (iconOpen) iconOpen.classList.toggle('hidden', open);
      if (iconClose) iconClose.classList.toggle('hidden', !open);
    };
    btn.addEventListener('click', function () {
      setOpen(menu.classList.contains('hidden'));
    });
    menu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { setOpen(false); });
    });
  }

  // Reveal on scroll (once)
  var items = document.querySelectorAll('.reveal, .reveal-scale');
  if (!items.length) return;
  if (!('IntersectionObserver' in window)) {
    items.forEach(function (el) { el.classList.add('is-visible'); });
    return;
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  items.forEach(function (el) { io.observe(el); });
})();
