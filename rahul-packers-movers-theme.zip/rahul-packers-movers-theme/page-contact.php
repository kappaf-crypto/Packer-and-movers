<?php
/**
 * Contact page (used automatically for the page with slug "contact").
 */
get_header();
$f = rpm_field_class();
?>
<div class="pt-16">
  <section class="py-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="reveal text-center mb-12">
        <h1 class="font-display text-4xl font-bold mb-4">Contact Us</h1>
        <p class="text-gray-400">Get in touch with us for any queries</p>
      </div>

      <div class="grid md:grid-cols-2 gap-12">
        <div class="space-y-6">
          <div class="glass-card p-6">
            <?php echo rpm_icon('phone', 32, 'text-accent-orange mb-4'); ?>
            <h3 class="font-semibold mb-2">Phone</h3>
            <a href="<?php echo esc_url(rpm_tel()); ?>" class="text-gray-400 hover:text-accent-orange"><?php echo esc_html(rpm_phone()); ?></a>
          </div>

          <div class="glass-card p-6">
            <?php echo rpm_icon('message-circle', 32, 'text-green-500 mb-4'); ?>
            <h3 class="font-semibold mb-2">WhatsApp</h3>
            <a href="<?php echo esc_url(rpm_wa()); ?>" target="_blank" rel="noopener noreferrer" class="text-gray-400 hover:text-green-500">Chat on WhatsApp</a>
          </div>

          <div class="glass-card p-6">
            <?php echo rpm_icon('mail', 32, 'text-accent-blue mb-4'); ?>
            <h3 class="font-semibold mb-2">Email</h3>
            <a href="mailto:<?php echo esc_attr(rpm_email()); ?>" class="text-gray-400 hover:text-accent-blue"><?php echo esc_html(rpm_email()); ?></a>
          </div>
        </div>

        <div id="contact-form" class="glass-card p-8">
          <h3 class="font-display text-xl font-bold mb-6">Send Message</h3>
          <?php rpm_form_notice(); ?>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="space-y-4">
            <input type="hidden" name="action" value="rpm_form">
            <input type="hidden" name="rpm_type" value="message">
            <?php wp_nonce_field('rpm_form', 'rpm_nonce'); ?>
            <div style="position:absolute;left:-9999px" aria-hidden="true">
              <label>Leave this empty <input type="text" name="rpm_website" tabindex="-1" autocomplete="off"></label>
            </div>
            <input type="text" name="rpm[name]" placeholder="Your Name" required class="<?php echo esc_attr($f); ?>">
            <input type="email" name="rpm[email]" placeholder="Email" class="<?php echo esc_attr($f); ?>">
            <input type="tel" name="rpm[phone]" placeholder="Phone" required class="<?php echo esc_attr($f); ?>">
            <textarea name="rpm[message]" placeholder="Message" rows="4" class="<?php echo esc_attr($f); ?>"></textarea>
            <button type="submit" class="btn-primary w-full">Send Message</button>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>
<?php get_footer(); ?>
