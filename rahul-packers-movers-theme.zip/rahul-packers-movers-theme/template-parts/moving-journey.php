<?php
$steps = array(
    array('package', 'Professional Packing', 'Expert packing with premium materials'),
    array('truck',   'Safe Loading',         'Careful loading with modern equipment'),
    array('map-pin', 'Transportation',       'GPS-tracked safe transportation'),
    array('home',    'Doorstep Delivery',    'On-time delivery to your doorstep'),
);
?>
<section class="py-20 bg-navy-950">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="reveal text-center mb-12">
      <h2 class="font-display text-4xl font-bold mb-4">Your Moving Journey</h2>
      <p class="text-gray-400">Simple 4-step process for hassle-free relocation</p>
    </div>

    <div class="grid md:grid-cols-4 gap-8">
      <?php foreach ($steps as $i => $s) : ?>
        <div class="reveal text-center" style="transition-delay:<?php echo (int) ($i * 200); ?>ms">
          <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-accent-orange/20 flex items-center justify-center">
            <?php echo rpm_icon($s[0], 32, 'text-accent-orange'); ?>
          </div>
          <h3 class="font-display text-xl font-semibold mb-2"><?php echo esc_html($s[1]); ?></h3>
          <p class="text-gray-400"><?php echo esc_html($s[2]); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
