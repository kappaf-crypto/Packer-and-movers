<?php
$stats = array(
    array('map-pin',    '50+',  'Cities'),
    array('route',      '200+', 'Routes'),
    array('headphones', '24/7', 'Support'),
);
?>
<section class="py-20 bg-navy-900">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="reveal text-center mb-12">
      <h2 class="font-display text-4xl font-bold mb-4">Pan India Coverage</h2>
      <p class="text-gray-400 max-w-2xl mx-auto">Serving across India with extensive network and reliable services</p>
    </div>

    <div class="grid md:grid-cols-3 gap-8">
      <?php foreach ($stats as $i => $s) : ?>
        <div class="reveal-scale glass-card p-8 text-center" style="transition-delay:<?php echo (int) ($i * 100); ?>ms">
          <?php echo rpm_icon($s[0], 40, 'text-accent-orange mx-auto mb-4'); ?>
          <div class="font-display text-4xl font-bold gradient-text mb-2"><?php echo esc_html($s[1]); ?></div>
          <div class="text-gray-400"><?php echo esc_html($s[2]); ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
