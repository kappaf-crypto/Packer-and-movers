<section class="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
  <div class="absolute inset-0 bg-gradient-to-br from-navy-950 via-navy-900 to-black">
    <div class="absolute inset-0 opacity-20">
      <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-accent-orange/30 rounded-full blur-3xl"></div>
      <div class="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-blue/30 rounded-full blur-3xl"></div>
    </div>
  </div>

  <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div class="reveal" style="transition-duration:0.8s">
      <h1 class="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6">
        Move Anywhere Across India
        <br>
        <span class="gradient-text">With Confidence</span>
      </h1>

      <p class="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto mb-8">
        Rahul Packers and Movers provides safe packing, reliable transportation
        and doorstep relocation services across India.
      </p>

      <div class="flex flex-col sm:flex-row gap-4 justify-center">
        <a href="<?php echo esc_url(rpm_tel()); ?>" class="btn-primary flex items-center justify-center gap-2">
          <?php echo rpm_icon('phone', 20); ?>
          Call Now
        </a>
        <a href="#quote" class="btn-secondary flex items-center justify-center gap-2">
          Get Free Quote
          <?php echo rpm_icon('arrow-right', 20); ?>
        </a>
      </div>
    </div>
  </div>
</section>
