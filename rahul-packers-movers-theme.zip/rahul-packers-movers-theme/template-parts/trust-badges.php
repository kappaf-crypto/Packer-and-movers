<?php
$badges = array('Verified Packers', 'Door-to-Door Delivery', 'Live Tracking', 'Secure Packing');
?>
<section class="py-12 bg-navy-900/50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <?php foreach ($badges as $i => $badge) : ?>
        <div class="reveal flex items-center gap-2 justify-center p-4 glass-card" style="transition-delay:<?php echo (int) ($i * 100); ?>ms">
          <?php echo rpm_icon('check-circle', 20, 'text-accent-orange'); ?>
          <span class="text-sm font-medium"><?php echo esc_html($badge); ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
