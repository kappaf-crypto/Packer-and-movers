<?php
$services = array(
    array('home',      'Home Relocation',      'Complete home shifting solutions with professional packing and safe transportation.'),
    array('building',  'Office Relocation',    'Seamless office moving services with minimal downtime and maximum efficiency.'),
    array('car',       'Car Transportation',   'Safe car carrier services with specialized vehicles for secure transportation.'),
    array('bike',      'Bike Transportation',  'Secure bike transport with proper packaging and handling.'),
    array('briefcase', 'Corporate Relocation', 'Employee relocation services for smooth business transitions.'),
    array('warehouse', 'Storage Solutions',    'Warehouse and storage facilities for short and long-term needs.'),
);
?>
<section class="py-20 bg-navy-900">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="reveal text-center mb-12">
      <h2 class="font-display text-4xl font-bold mb-4">Our Services</h2>
      <p class="text-gray-400 max-w-2xl mx-auto">Comprehensive relocation solutions tailored to your needs</p>
    </div>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php foreach ($services as $i => $s) : ?>
        <div class="reveal glass-card p-6 hover:border-accent-orange/50 transition-all" style="transition-delay:<?php echo (int) ($i * 100); ?>ms">
          <?php echo rpm_icon($s[0], 40, 'text-accent-orange mb-4'); ?>
          <h3 class="font-display text-xl font-semibold mb-2"><?php echo esc_html($s[1]); ?></h3>
          <p class="text-gray-400 mb-4"><?php echo esc_html($s[2]); ?></p>
          <button type="button" class="flex items-center gap-2 text-accent-orange hover:gap-3 transition-all">
            Learn More <?php echo rpm_icon('arrow-right', 16); ?>
          </button>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
