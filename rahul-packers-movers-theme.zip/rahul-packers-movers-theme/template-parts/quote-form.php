<?php $f = rpm_field_class(); ?>
<section id="quote" class="py-20 bg-navy-950">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="reveal glass-card p-8">
      <h2 class="font-display text-3xl font-bold text-center mb-8">Get Free Moving Quote</h2>

      <?php rpm_form_notice(); ?>

      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="space-y-6">
        <input type="hidden" name="action" value="rpm_form">
        <input type="hidden" name="rpm_type" value="quote">
        <?php wp_nonce_field('rpm_form', 'rpm_nonce'); ?>
        <div style="position:absolute;left:-9999px" aria-hidden="true">
          <label>Leave this empty <input type="text" name="rpm_website" tabindex="-1" autocomplete="off"></label>
        </div>

        <div class="grid md:grid-cols-2 gap-6">
          <input type="text" name="rpm[name]" placeholder="Your Name" required class="<?php echo esc_attr($f); ?>">
          <input type="tel" name="rpm[phone]" placeholder="Phone Number" required class="<?php echo esc_attr($f); ?>">
          <input type="email" name="rpm[email]" placeholder="Email" class="<?php echo esc_attr($f); ?>">
          <input type="text" name="rpm[from_city]" placeholder="Moving From" required class="<?php echo esc_attr($f); ?>">
          <input type="text" name="rpm[to_city]" placeholder="Moving To" required class="<?php echo esc_attr($f); ?>">
          <select name="rpm[house_size]" class="<?php echo esc_attr($f); ?>">
            <option value="">House Size</option>
            <option value="1 RK">1 RK</option>
            <option value="1 BHK">1 BHK</option>
            <option value="2 BHK">2 BHK</option>
            <option value="3 BHK">3 BHK</option>
            <option value="4 BHK+">4 BHK+</option>
          </select>
          <input type="date" name="rpm[moving_date]" class="<?php echo esc_attr($f); ?>">
          <select name="rpm[service_type]" class="<?php echo esc_attr($f); ?>">
            <option value="">Service Type</option>
            <option value="Home Relocation">Home Relocation</option>
            <option value="Office Relocation">Office Relocation</option>
            <option value="Car Transportation">Car Transportation</option>
            <option value="Bike Transportation">Bike Transportation</option>
          </select>
        </div>

        <button type="submit" class="w-full btn-primary text-lg">Get Free Moving Quote</button>
      </form>
    </div>
  </div>
</section>
