<?php
/**
 * Tracking page (used automatically for the page with slug "tracking").
 * Looks up a "Shipment" (Shipments menu in wp-admin) by Booking ID.
 */
$booking = isset($_GET['booking_id']) ? trim(sanitize_text_field(wp_unslash($_GET['booking_id']))) : '';
$found   = null;
$step    = 0;
if ($booking !== '') {
    $q = new WP_Query(array(
        'post_type'      => 'shipment',
        'post_status'    => 'publish',
        'title'          => $booking,
        'posts_per_page' => 1,
        'no_found_rows'  => true,
    ));
    if ($q->have_posts()) {
        $found = $q->posts[0];
        $step  = (int) get_post_meta($found->ID, 'rpm_step', true);
        $step  = max(1, min(5, $step ? $step : 1));
        $route = get_post_meta($found->ID, 'rpm_route', true);
    }
    wp_reset_postdata();
}
get_header();
?>
<div class="pt-16">
  <section class="py-20">
    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="reveal text-center mb-12">
        <h1 class="font-display text-4xl font-bold mb-4">Track Your Shipment</h1>
        <p class="text-gray-400">Enter your booking ID to track your shipment</p>
      </div>

      <form method="get" action="<?php echo esc_url(get_permalink()); ?>" class="glass-card p-8 mb-8">
        <div class="flex gap-4">
          <input type="text" name="booking_id" placeholder="Enter Booking ID (e.g., RPM20260001)" value="<?php echo esc_attr($booking); ?>" required class="flex-1 p-3 bg-white/5 border border-white/10 rounded-lg focus:border-accent-orange outline-none">
          <button type="submit" class="btn-primary flex items-center gap-2">
            <?php echo rpm_icon('search', 20); ?>
            Track
          </button>
        </div>
      </form>

      <?php if ($booking !== '' && !$found) : ?>
        <div class="glass-card p-8 text-center text-gray-300">
          No shipment found for <strong><?php echo esc_html($booking); ?></strong>. Please check the Booking ID or call us on
          <a href="<?php echo esc_url(rpm_tel()); ?>" class="text-accent-orange"><?php echo esc_html(rpm_phone()); ?></a>.
        </div>
      <?php elseif ($found) : ?>
        <div class="glass-card p-8">
          <h3 class="font-display text-xl font-bold mb-2">Booking ID: <?php echo esc_html($found->post_title); ?></h3>
          <?php if (!empty($route)) : ?>
            <p class="text-gray-400 mb-6"><?php echo esc_html($route); ?></p>
          <?php else : ?>
            <div class="mb-6"></div>
          <?php endif; ?>
          <div class="space-y-4">
            <?php foreach (rpm_steps() as $i => $s) : $done = ($i < $step); ?>
              <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-full flex items-center justify-center <?php echo $done ? 'bg-accent-orange' : 'bg-gray-700'; ?>">
                  <?php echo rpm_icon($s['icon'], 20); ?>
                </div>
                <span class="<?php echo $done ? 'text-white' : 'text-gray-500'; ?>"><?php echo esc_html($s['label']); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </section>
</div>
<?php get_footer(); ?>
