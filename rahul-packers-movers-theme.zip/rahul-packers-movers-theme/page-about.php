<?php
/**
 * About page (used automatically for the page with slug "about").
 */
get_header();
?>
<div class="pt-16">
  <section class="py-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="reveal text-center mb-12">
        <h1 class="font-display text-4xl font-bold mb-4">About Us</h1>
        <p class="text-gray-400 max-w-2xl mx-auto">India's Trusted Relocation Partner</p>
      </div>

      <div class="grid md:grid-cols-2 gap-12 items-center">
        <div>
          <h2 class="font-display text-2xl font-bold mb-4">Our Story</h2>
          <p class="text-gray-400 mb-4">
            Rahul Packers and Movers has been providing reliable relocation services
            across India. We understand that moving can be stressful, and our mission
            is to make it smooth and hassle-free.
          </p>
          <p class="text-gray-400">
            With our experienced team, modern equipment, and commitment to customer
            satisfaction, we have become one of the most trusted names in the
            relocation industry.
          </p>
        </div>
        <div class="glass-card p-8">
          <h3 class="font-display text-xl font-bold mb-4">Why Choose Us</h3>
          <ul class="space-y-3 text-gray-400">
            <li>✓ Professional and experienced team</li>
            <li>✓ GPS-tracked transportation</li>
            <li>✓ Comprehensive insurance coverage</li>
            <li>✓ 24/7 customer support</li>
            <li>✓ Transparent pricing</li>
          </ul>
        </div>
      </div>
    </div>
  </section>
</div>
<?php get_footer(); ?>
