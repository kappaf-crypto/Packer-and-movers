<?php
/**
 * Default page template.
 */
get_header();
?>
<div class="pt-16">
  <section class="py-20">
    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <?php while (have_posts()) : the_post(); ?>
        <h1 class="font-display text-4xl font-bold mb-8 text-center"><?php the_title(); ?></h1>
        <div class="entry-content"><?php the_content(); ?></div>
      <?php endwhile; ?>
    </div>
  </section>
</div>
<?php get_footer(); ?>
