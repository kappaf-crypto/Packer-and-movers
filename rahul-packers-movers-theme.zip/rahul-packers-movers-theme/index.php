<?php
/**
 * Fallback template (blog index, posts, archives).
 */
get_header();
?>
<div class="pt-16">
  <section class="py-20">
    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article class="mb-12">
          <h1 class="font-display text-3xl font-bold mb-4">
            <?php if (is_singular()) : the_title(); else : ?>
              <a href="<?php the_permalink(); ?>" class="hover:text-accent-orange"><?php the_title(); ?></a>
            <?php endif; ?>
          </h1>
          <div class="entry-content">
            <?php is_singular() ? the_content() : the_excerpt(); ?>
          </div>
        </article>
      <?php endwhile; the_posts_pagination(); else : ?>
        <p class="text-gray-400">Nothing found.</p>
      <?php endif; ?>
    </div>
  </section>
</div>
<?php get_footer(); ?>
