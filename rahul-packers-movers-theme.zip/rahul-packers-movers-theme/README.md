# Rahul Packers and Movers - WordPress Theme

Converted from the Next.js site. Plain PHP theme, no plugins required.

## Install
1. Zip this folder (or upload the provided zip) via Appearance > Themes > Add New > Upload Theme.
2. Activate it.
3. Create these pages (the slug decides which template is used):
   - About -> slug `about`
   - Contact -> slug `contact`
   - Tracking -> slug `tracking`
4. Settings > Reading > "Your homepage displays" > A static page (pick any page; the home template loads automatically).
5. Settings > Permalinks > choose "Post name" and Save.
6. Appearance > Customize > Contact Details to change phone, WhatsApp and email.

## Quote / contact forms
Submissions are saved under **Quote Requests** in wp-admin and emailed to the site admin email (Settings > General).
For reliable delivery install an SMTP plugin (WP Mail SMTP, FluentSMTP).

## Shipment tracking
Add shipments under **Shipments > Add New**. Title = Booking ID (e.g. RPM20260001), then pick the current stage.
Customers enter that ID on the Tracking page.

## Editing CSS (developers only)
`assets/css/main.css` is pre-compiled Tailwind. To change styles:
```
npm install -D tailwindcss@3
npx tailwindcss -i input.css -o assets/css/main.css --minify
```
